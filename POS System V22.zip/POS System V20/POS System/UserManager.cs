﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public static class UserManager
    {
        //Instantiate a static database to eliminate redundancy
        public static databasePOS db = new databasePOS();
        
        //Declare variables to store information
        public static string role;
        public static string userID;
        public static string id;
        public static int updateID;

        //Add public class 
        public class MenuItem
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public decimal Price { get; set; }
            public byte[] Image { get; set; }
            public string Category { get; set; }
            public int Stock { get; set; }
        }

        //==================================LOGIN VALIDATION====================================//

        //checks if account is null or not
        public static bool checkAccount(string userId, string password)
        {
            return (db.tblAccounts.Any(u => u.EMPLOYEEID == userId && u.PASSWORD == password));
        }
        //checks inactive account
        public static void checkInactiveAccount(string userId, Login login)
        {
            var user = db.tblAccounts.FirstOrDefault(u => u.EMPLOYEEID == userId);

            if (user != null)
            {
                if (user.STATUS == "INACTIVE") //checks if inactive
                {
                    MessageBox.Show("The Account you are trying to login is no longer ACTIVE");
                }
                else //if active, proceed to mainform
                {
                    login.ClearLoginFields();
                    role = user.ROLE;
                    userID = user.EMPLOYEEID;
                    id = user.ID.ToString();
                    MessageBox.Show("Login Success!");
                    new mainForm(login).Show();
                    login.Hide();
                }
            }
        }
    }
}
