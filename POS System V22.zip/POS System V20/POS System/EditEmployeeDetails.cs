﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace POS_System
{
    public partial class EditEmployeeDetails : Form
    {
        //Initialization
        int age;
        public EditEmployeeDetails()
        {
            InitializeComponent();
            PopulateTextbox();
        }

        //populate data
        private void PopulateTextbox()
        {

            //Class initializatiion
            var user = UserManager.db.tblAccounts.FirstOrDefault(u => u.ID == int.Parse(UserManager.id));
            var user2 = UserManager.db.tblEmployeeDetails.FirstOrDefault(u => u.ID == int.Parse(UserManager.id));

            if (user != null)
            {
                tb_fName.Text = user2.FIRST_NAME;
                tb_lName.Text = user2.LAST_NAME;
                tb_mName.Text = user2.MIDDLE_NAME;
                cmb_sex.Text = user2.SEX;
                tb_age.Text = user2.AGE;
                tb_phone.Text = user2.PHONENUMBER.ToString();
                tb_password.Text = user.PASSWORD;
                if (user2.BIRTHDAY != null)
                {
                    dtp_bday.Value = Convert.ToDateTime(user2.BIRTHDAY);
                }
                
            }
        }

        //update dataGridView
        private void btn_update_Click(object sender, EventArgs e)
        {
            //Class initializatiion
            var user = UserManager.db.tblAccounts.FirstOrDefault(u => u.ID == int.Parse(UserManager.id));
            var user2 = UserManager.db.tblEmployeeDetails.FirstOrDefault(u => u.ID == int.Parse(UserManager.id));
            bool proceed = true;
            
            //Restrictions
            if (user != null)
            {
                foreach (Control x in this.Controls)
                {
                    //Textbox restrictions
                    if (x is KryptonTextBox && (string)x.Tag == "tb" && string.IsNullOrWhiteSpace(x.Text))
                    {
                        MessageBox.Show("Fields cannot be empty");
                        proceed = false;
                        break;
                    }
                    else
                    {
                        proceed = true;
                    }
                }

                //ComboBox Restrictions for Sex
                if (string.IsNullOrWhiteSpace(cmb_sex.Text))
                {
                    proceed = false;
                    MessageBox.Show("Please enter valid sex");
                }

                //Age Restrictions
                if (proceed)
                {
                    if (age < 18)
                    {
                        MessageBox.Show("Age must be 18 or above");
                    }
                    else
                    {
                        //Confirmation for updates
                        DialogResult result = MessageBox.Show("Commit Changes?", "Warning", MessageBoxButtons.YesNo);

                        //Validation
                        if (result == DialogResult.Yes)
                        {
                            DateTime date = dtp_bday.Value.Date;
                            long phone = 0;

                            if (string.IsNullOrWhiteSpace(tb_phone.Text))
                            {
                                phone = 0;
                            }
                            else
                            {
                                phone = long.Parse(tb_phone.Text);
                            }
                            UserManager.db.updateEmployeeDetails(int.Parse(UserManager.id), tb_fName.Text.ToUpper().Trim(), tb_lName.Text.ToUpper().Trim(), tb_mName.Text.ToUpper().Trim(), cmb_sex.Text, age.ToString(), phone, tb_password.Text.ToUpper().Trim(), date);
                            MessageBox.Show("Employee details successfuly updated");


                        }
                        else
                        {
                            PopulateTextbox();
                        }
                    }
                }
            }
        }

        //hide and show password methhod
        private void chk_show_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_show.Checked)
            {
                tb_password.PasswordChar = '\0';
            }
            else
            {
                tb_password.PasswordChar = '*';
            }
            
        }

        //configure bdate
        private void dtp_bday_ValueChanged(object sender, EventArgs e)
        {
            DateTime bday = dtp_bday.Value;
            DateTime today = DateTime.Now;

            age = today.Year - bday.Year;

            if (bday > today.AddYears(-age))
            {
                age--;
            }

            tb_age.Text = age.ToString();
        }

        //alow enter
        private void tb_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
