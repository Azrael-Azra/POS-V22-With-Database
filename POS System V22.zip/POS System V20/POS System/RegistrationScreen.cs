﻿using ComponentFactory.Krypton.Toolkit;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class RegistrationScreen : Form
    {
        databasePOS db = new databasePOS();
        public RegistrationScreen()
        {
            InitializeComponent();
        }

        //restrict saving
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_ins_firstName.Text) ||
                string.IsNullOrWhiteSpace(tb_ins_lastName.Text) ||
                string.IsNullOrWhiteSpace(tb_ins_firstName.Text) ||
                string.IsNullOrWhiteSpace(tb_ins_role.Text))
            {
                MessageBox.Show("Fields must not be empty");
            }
            else
            {
                db.InstantaddUser(tb_ins_role.Text.ToUpper().Trim(), tb_ins_lastName.Text.ToUpper().Trim() + (db.tblAccounts.Count() + 1), tb_ins_firstName.Text.ToUpper().Trim(), tb_ins_lastName.Text.ToUpper().Trim(), tb_ins_firstName.Text.ToUpper().Trim());
                MessageBox.Show("Account Successfuly Created");
            }

        }

  
    }
}
