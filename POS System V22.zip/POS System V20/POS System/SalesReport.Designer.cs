﻿namespace POS_System
{
    partial class SalesReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgv_showData = new System.Windows.Forms.DataGridView();
            this.lbl_employeeID = new System.Windows.Forms.Label();
            this.lbl_transactionID = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.pnlBg = new System.Windows.Forms.Panel();
            this.pnl_search = new System.Windows.Forms.Panel();
            this.cmb_searchBY = new System.Windows.Forms.ComboBox();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.lblsearchBy = new System.Windows.Forms.Label();
            this.lbl_totalSales = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_showTransactions = new System.Windows.Forms.Button();
            this.dgv_showDetails = new System.Windows.Forms.DataGridView();
            this.lblProducts = new System.Windows.Forms.Label();
            this.pnlInformation = new System.Windows.Forms.Panel();
            this.pnl_date2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_filterBYdate2 = new System.Windows.Forms.Button();
            this.ToDatePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.FromDatePicker2 = new System.Windows.Forms.DateTimePicker();
            this.lblfrom = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitleInfo = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).BeginInit();
            this.pnlBg.SuspendLayout();
            this.pnl_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showDetails)).BeginInit();
            this.pnlInformation.SuspendLayout();
            this.pnl_date2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.lblTitle.Location = new System.Drawing.Point(37, 39);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(110, 23);
            this.lblTitle.TabIndex = 92;
            this.lblTitle.Text = "Sales Report";
            // 
            // dgv_showData
            // 
            this.dgv_showData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_showData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_showData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.dgv_showData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_showData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showData.Location = new System.Drawing.Point(12, 40);
            this.dgv_showData.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_showData.Name = "dgv_showData";
            this.dgv_showData.ReadOnly = true;
            this.dgv_showData.RowHeadersWidth = 51;
            this.dgv_showData.RowTemplate.Height = 24;
            this.dgv_showData.Size = new System.Drawing.Size(723, 252);
            this.dgv_showData.TabIndex = 44;
            this.dgv_showData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_showData_CellClick);
            // 
            // lbl_employeeID
            // 
            this.lbl_employeeID.AutoSize = true;
            this.lbl_employeeID.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeeID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_employeeID.Location = new System.Drawing.Point(146, 57);
            this.lbl_employeeID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_employeeID.Name = "lbl_employeeID";
            this.lbl_employeeID.Size = new System.Drawing.Size(20, 17);
            this.lbl_employeeID.TabIndex = 83;
            this.lbl_employeeID.Text = "--";
            // 
            // lbl_transactionID
            // 
            this.lbl_transactionID.AutoSize = true;
            this.lbl_transactionID.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transactionID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_transactionID.Location = new System.Drawing.Point(13, 57);
            this.lbl_transactionID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_transactionID.Name = "lbl_transactionID";
            this.lbl_transactionID.Size = new System.Drawing.Size(20, 17);
            this.lbl_transactionID.TabIndex = 81;
            this.lbl_transactionID.Text = "--";
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(182)))), ((int)(((byte)(102)))));
            this.btnView.FlatAppearance.BorderSize = 0;
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnView.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnView.Location = new System.Drawing.Point(254, 49);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(101, 26);
            this.btnView.TabIndex = 1;
            this.btnView.Text = "View Details";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // pnlBg
            // 
            this.pnlBg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBg.BackColor = System.Drawing.Color.White;
            this.pnlBg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBg.Controls.Add(this.pnl_search);
            this.pnlBg.Controls.Add(this.lbl_totalSales);
            this.pnlBg.Controls.Add(this.label6);
            this.pnlBg.Controls.Add(this.btn_showTransactions);
            this.pnlBg.Controls.Add(this.dgv_showDetails);
            this.pnlBg.Controls.Add(this.dgv_showData);
            this.pnlBg.Controls.Add(this.lblProducts);
            this.pnlBg.Location = new System.Drawing.Point(42, 182);
            this.pnlBg.Name = "pnlBg";
            this.pnlBg.Size = new System.Drawing.Size(750, 323);
            this.pnlBg.TabIndex = 93;
            // 
            // pnl_search
            // 
            this.pnl_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_search.Controls.Add(this.cmb_searchBY);
            this.pnl_search.Controls.Add(this.tb_search);
            this.pnl_search.Controls.Add(this.lblsearchBy);
            this.pnl_search.Location = new System.Drawing.Point(414, 3);
            this.pnl_search.Name = "pnl_search";
            this.pnl_search.Size = new System.Drawing.Size(321, 35);
            this.pnl_search.TabIndex = 95;
            // 
            // cmb_searchBY
            // 
            this.cmb_searchBY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmb_searchBY.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_searchBY.Font = new System.Drawing.Font("Inter", 8.1F);
            this.cmb_searchBY.FormattingEnabled = true;
            this.cmb_searchBY.Items.AddRange(new object[] {
            "Transaction ID",
            "Employee ID"});
            this.cmb_searchBY.Location = new System.Drawing.Point(77, 6);
            this.cmb_searchBY.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_searchBY.Name = "cmb_searchBY";
            this.cmb_searchBY.Size = new System.Drawing.Size(92, 24);
            this.cmb_searchBY.TabIndex = 86;
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.BackColor = System.Drawing.Color.White;
            this.tb_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_search.Font = new System.Drawing.Font("Inter", 8.25F);
            this.tb_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.tb_search.Location = new System.Drawing.Point(172, 8);
            this.tb_search.MaxLength = 5;
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(149, 21);
            this.tb_search.TabIndex = 85;
            this.tb_search.TextChanged += new System.EventHandler(this.txtPaidInCash_TextChanged);
            this.tb_search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_search_KeyPress);
            // 
            // lblsearchBy
            // 
            this.lblsearchBy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblsearchBy.AutoSize = true;
            this.lblsearchBy.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearchBy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblsearchBy.Location = new System.Drawing.Point(17, 11);
            this.lblsearchBy.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsearchBy.Name = "lblsearchBy";
            this.lblsearchBy.Size = new System.Drawing.Size(62, 16);
            this.lblsearchBy.TabIndex = 86;
            this.lblsearchBy.Text = "Search by:";
            // 
            // lbl_totalSales
            // 
            this.lbl_totalSales.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totalSales.AutoSize = true;
            this.lbl_totalSales.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalSales.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_totalSales.Location = new System.Drawing.Point(656, 298);
            this.lbl_totalSales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_totalSales.Name = "lbl_totalSales";
            this.lbl_totalSales.Size = new System.Drawing.Size(20, 17);
            this.lbl_totalSales.TabIndex = 86;
            this.lbl_totalSales.Text = "--";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label6.Location = new System.Drawing.Point(583, 299);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 16);
            this.label6.TabIndex = 85;
            this.label6.Text = "Total Sales";
            // 
            // btn_showTransactions
            // 
            this.btn_showTransactions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(61)))), ((int)(((byte)(61)))));
            this.btn_showTransactions.FlatAppearance.BorderSize = 0;
            this.btn_showTransactions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_showTransactions.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showTransactions.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_showTransactions.Image = global::POS_System.Properties.Resources.rotating_arrow_to_the_right_1__2_;
            this.btn_showTransactions.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_showTransactions.Location = new System.Drawing.Point(84, 8);
            this.btn_showTransactions.Name = "btn_showTransactions";
            this.btn_showTransactions.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.btn_showTransactions.Size = new System.Drawing.Size(155, 26);
            this.btn_showTransactions.TabIndex = 85;
            this.btn_showTransactions.Text = "Load All Transaction";
            this.btn_showTransactions.UseVisualStyleBackColor = false;
            this.btn_showTransactions.Click += new System.EventHandler(this.btn_showTransactions_Click);
            // 
            // dgv_showDetails
            // 
            this.dgv_showDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_showDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_showDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.dgv_showDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_showDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showDetails.Location = new System.Drawing.Point(12, 40);
            this.dgv_showDetails.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_showDetails.Name = "dgv_showDetails";
            this.dgv_showDetails.ReadOnly = true;
            this.dgv_showDetails.RowHeadersWidth = 51;
            this.dgv_showDetails.RowTemplate.Height = 24;
            this.dgv_showDetails.Size = new System.Drawing.Size(723, 252);
            this.dgv_showDetails.TabIndex = 45;
            this.dgv_showDetails.Visible = false;
            // 
            // lblProducts
            // 
            this.lblProducts.AutoSize = true;
            this.lblProducts.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProducts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblProducts.Location = new System.Drawing.Point(13, 13);
            this.lblProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(64, 21);
            this.lblProducts.TabIndex = 42;
            this.lblProducts.Text = "Reports";
            // 
            // pnlInformation
            // 
            this.pnlInformation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInformation.BackColor = System.Drawing.Color.White;
            this.pnlInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInformation.Controls.Add(this.btnView);
            this.pnlInformation.Controls.Add(this.pnl_date2);
            this.pnlInformation.Controls.Add(this.label1);
            this.pnlInformation.Controls.Add(this.lblTitleInfo);
            this.pnlInformation.Controls.Add(this.lbl_employeeID);
            this.pnlInformation.Controls.Add(this.lblLname);
            this.pnlInformation.Controls.Add(this.lbl_transactionID);
            this.pnlInformation.Controls.Add(this.lblFname);
            this.pnlInformation.Location = new System.Drawing.Point(41, 75);
            this.pnlInformation.Margin = new System.Windows.Forms.Padding(2);
            this.pnlInformation.Name = "pnlInformation";
            this.pnlInformation.Size = new System.Drawing.Size(749, 86);
            this.pnlInformation.TabIndex = 94;
            // 
            // pnl_date2
            // 
            this.pnl_date2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_date2.Controls.Add(this.label3);
            this.pnl_date2.Controls.Add(this.btn_filterBYdate2);
            this.pnl_date2.Controls.Add(this.ToDatePicker2);
            this.pnl_date2.Controls.Add(this.label4);
            this.pnl_date2.Controls.Add(this.FromDatePicker2);
            this.pnl_date2.Controls.Add(this.lblfrom);
            this.pnl_date2.Location = new System.Drawing.Point(361, 0);
            this.pnl_date2.Name = "pnl_date2";
            this.pnl_date2.Size = new System.Drawing.Size(389, 84);
            this.pnl_date2.TabIndex = 98;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(23, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 21);
            this.label3.TabIndex = 91;
            this.label3.Text = "Filter";
            // 
            // btn_filterBYdate2
            // 
            this.btn_filterBYdate2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.btn_filterBYdate2.FlatAppearance.BorderSize = 0;
            this.btn_filterBYdate2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_filterBYdate2.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filterBYdate2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_filterBYdate2.Location = new System.Drawing.Point(383, 48);
            this.btn_filterBYdate2.Name = "btn_filterBYdate2";
            this.btn_filterBYdate2.Size = new System.Drawing.Size(60, 25);
            this.btn_filterBYdate2.TabIndex = 90;
            this.btn_filterBYdate2.Text = "Sort";
            this.btn_filterBYdate2.UseVisualStyleBackColor = false;
            this.btn_filterBYdate2.Click += new System.EventHandler(this.btn_filterBYdate2_Click);
            // 
            // ToDatePicker2
            // 
            this.ToDatePicker2.Location = new System.Drawing.Point(204, 53);
            this.ToDatePicker2.Name = "ToDatePicker2";
            this.ToDatePicker2.Size = new System.Drawing.Size(171, 20);
            this.ToDatePicker2.TabIndex = 87;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.label4.Location = new System.Drawing.Point(207, 34);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 17);
            this.label4.TabIndex = 89;
            this.label4.Text = "To";
            // 
            // FromDatePicker2
            // 
            this.FromDatePicker2.Location = new System.Drawing.Point(27, 53);
            this.FromDatePicker2.Name = "FromDatePicker2";
            this.FromDatePicker2.Size = new System.Drawing.Size(170, 20);
            this.FromDatePicker2.TabIndex = 86;
            // 
            // lblfrom
            // 
            this.lblfrom.AutoSize = true;
            this.lblfrom.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfrom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lblfrom.Location = new System.Drawing.Point(24, 35);
            this.lblfrom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblfrom.Name = "lblfrom";
            this.lblfrom.Size = new System.Drawing.Size(38, 17);
            this.lblfrom.TabIndex = 88;
            this.lblfrom.Text = "From";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(251, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 21);
            this.label1.TabIndex = 84;
            this.label1.Text = "Actions";
            // 
            // lblTitleInfo
            // 
            this.lblTitleInfo.AutoSize = true;
            this.lblTitleInfo.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTitleInfo.Location = new System.Drawing.Point(12, 10);
            this.lblTitleInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitleInfo.Name = "lblTitleInfo";
            this.lblTitleInfo.Size = new System.Drawing.Size(97, 21);
            this.lblTitleInfo.TabIndex = 69;
            this.lblTitleInfo.Text = "Sales Details";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblLname.Location = new System.Drawing.Point(146, 35);
            this.lblLname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(76, 16);
            this.lblLname.TabIndex = 65;
            this.lblLname.Text = "Employee ID:";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblFname.Location = new System.Drawing.Point(13, 35);
            this.lblFname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(112, 16);
            this.lblFname.TabIndex = 63;
            this.lblFname.Text = "Transaction Number";
            // 
            // SalesReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pnlBg);
            this.Controls.Add(this.pnlInformation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SalesReport";
            this.Text = "SalesReport";
            this.Load += new System.EventHandler(this.SalesReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).EndInit();
            this.pnlBg.ResumeLayout(false);
            this.pnlBg.PerformLayout();
            this.pnl_search.ResumeLayout(false);
            this.pnl_search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showDetails)).EndInit();
            this.pnlInformation.ResumeLayout(false);
            this.pnlInformation.PerformLayout();
            this.pnl_date2.ResumeLayout(false);
            this.pnl_date2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgv_showData;
        private System.Windows.Forms.Label lbl_employeeID;
        private System.Windows.Forms.Label lbl_transactionID;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Panel pnlBg;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Panel pnlInformation;
        private System.Windows.Forms.Button btn_showTransactions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTitleInfo;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.DataGridView dgv_showDetails;
        private System.Windows.Forms.Panel pnl_date2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_filterBYdate2;
        private System.Windows.Forms.DateTimePicker ToDatePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker FromDatePicker2;
        private System.Windows.Forms.Label lblfrom;
        private System.Windows.Forms.Label lbl_totalSales;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnl_search;
        private System.Windows.Forms.ComboBox cmb_searchBY;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Label lblsearchBy;
    }
}