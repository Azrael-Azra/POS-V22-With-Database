﻿namespace POS_System
{
    partial class EmployeeManagementScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlEmployee = new System.Windows.Forms.Panel();
            this.dgvEmp = new System.Windows.Forms.DataGridView();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.lblTitleEmp = new System.Windows.Forms.Label();
            this.pnlBotoom = new System.Windows.Forms.Panel();
            this.btnHide = new System.Windows.Forms.Button();
            this.panelChildform = new System.Windows.Forms.Panel();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.lbl_employementID = new System.Windows.Forms.Label();
            this.lblEmpIDDisplay = new System.Windows.Forms.Label();
            this.lblTitleInfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.tb_firstName = new System.Windows.Forms.TextBox();
            this.lblLname = new System.Windows.Forms.Label();
            this.tb_lastName = new System.Windows.Forms.TextBox();
            this.lblMname = new System.Windows.Forms.Label();
            this.tb_middleName = new System.Windows.Forms.TextBox();
            this.cmb_sex = new System.Windows.Forms.ComboBox();
            this.lblSex = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.tb_age = new System.Windows.Forms.TextBox();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.tb_phone = new System.Windows.Forms.TextBox();
            this.dtp_bday = new System.Windows.Forms.DateTimePicker();
            this.lblBDate = new System.Windows.Forms.Label();
            this.cmb_status = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cmb_role = new System.Windows.Forms.ComboBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblPasswor = new System.Windows.Forms.Label();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.chk_show = new System.Windows.Forms.CheckBox();
            this.pnlInformation = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmp)).BeginInit();
            this.pnlBotoom.SuspendLayout();
            this.pnlInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlEmployee
            // 
            this.pnlEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEmployee.BackColor = System.Drawing.Color.White;
            this.pnlEmployee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEmployee.Controls.Add(this.dgvEmp);
            this.pnlEmployee.Controls.Add(this.button2);
            this.pnlEmployee.Controls.Add(this.tb_search);
            this.pnlEmployee.Controls.Add(this.lblTitleEmp);
            this.pnlEmployee.Location = new System.Drawing.Point(40, 221);
            this.pnlEmployee.Name = "pnlEmployee";
            this.pnlEmployee.Size = new System.Drawing.Size(750, 221);
            this.pnlEmployee.TabIndex = 41;
            // 
            // dgvEmp
            // 
            this.dgvEmp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEmp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEmp.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(248)))));
            this.dgvEmp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmp.Location = new System.Drawing.Point(11, 45);
            this.dgvEmp.Name = "dgvEmp";
            this.dgvEmp.RowHeadersWidth = 51;
            this.dgvEmp.Size = new System.Drawing.Size(727, 163);
            this.dgvEmp.TabIndex = 65;
            this.dgvEmp.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_search.Font = new System.Drawing.Font("Inter", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.tb_search.Location = new System.Drawing.Point(483, 12);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(223, 23);
            this.tb_search.TabIndex = 46;
            this.tb_search.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.tb_search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_search_KeyPress);
            // 
            // lblTitleEmp
            // 
            this.lblTitleEmp.AutoSize = true;
            this.lblTitleEmp.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleEmp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblTitleEmp.Location = new System.Drawing.Point(13, 14);
            this.lblTitleEmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitleEmp.Name = "lblTitleEmp";
            this.lblTitleEmp.Size = new System.Drawing.Size(65, 17);
            this.lblTitleEmp.TabIndex = 42;
            this.lblTitleEmp.Text = "Employee";
            // 
            // pnlBotoom
            // 
            this.pnlBotoom.BackColor = System.Drawing.Color.White;
            this.pnlBotoom.Controls.Add(this.panelChildform);
            this.pnlBotoom.Controls.Add(this.label1);
            this.pnlBotoom.Controls.Add(this.btnHide);
            this.pnlBotoom.Controls.Add(this.btnAddEmployee);
            this.pnlBotoom.Controls.Add(this.lbl_employementID);
            this.pnlBotoom.Controls.Add(this.lblEmpIDDisplay);
            this.pnlBotoom.Controls.Add(this.lblTitleInfo);
            this.pnlBotoom.Controls.Add(this.pnlInformation);
            this.pnlBotoom.Controls.Add(this.button3);
            this.pnlBotoom.Controls.Add(this.pnlEmployee);
            this.pnlBotoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBotoom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.pnlBotoom.Location = new System.Drawing.Point(0, 0);
            this.pnlBotoom.Name = "pnlBotoom";
            this.pnlBotoom.Size = new System.Drawing.Size(830, 529);
            this.pnlBotoom.TabIndex = 42;
            // 
            // btnHide
            // 
            this.btnHide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHide.FlatAppearance.BorderSize = 0;
            this.btnHide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHide.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHide.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.btnHide.Location = new System.Drawing.Point(796, 1);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(31, 33);
            this.btnHide.TabIndex = 89;
            this.btnHide.Text = "X";
            this.btnHide.UseVisualStyleBackColor = true;
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click_2);
            // 
            // panelChildform
            // 
            this.panelChildform.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelChildform.Location = new System.Drawing.Point(0, 39);
            this.panelChildform.Name = "panelChildform";
            this.panelChildform.Size = new System.Drawing.Size(830, 490);
            this.panelChildform.TabIndex = 88;
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddEmployee.BackColor = System.Drawing.Color.Transparent;
            this.btnAddEmployee.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(41)))), ((int)(((byte)(48)))));
            this.btnAddEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddEmployee.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.btnAddEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddEmployee.Location = new System.Drawing.Point(504, 448);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(138, 35);
            this.btnAddEmployee.TabIndex = 87;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = false;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // lbl_employementID
            // 
            this.lbl_employementID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_employementID.AutoSize = true;
            this.lbl_employementID.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employementID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_employementID.Location = new System.Drawing.Point(747, 83);
            this.lbl_employementID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_employementID.Name = "lbl_employementID";
            this.lbl_employementID.Size = new System.Drawing.Size(42, 16);
            this.lbl_employementID.TabIndex = 86;
            this.lbl_employementID.Text = "00000";
            // 
            // lblEmpIDDisplay
            // 
            this.lblEmpIDDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEmpIDDisplay.AutoSize = true;
            this.lblEmpIDDisplay.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpIDDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblEmpIDDisplay.Location = new System.Drawing.Point(651, 83);
            this.lblEmpIDDisplay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpIDDisplay.Name = "lblEmpIDDisplay";
            this.lblEmpIDDisplay.Size = new System.Drawing.Size(96, 16);
            this.lblEmpIDDisplay.TabIndex = 85;
            this.lblEmpIDDisplay.Text = "Employement ID:";
            // 
            // lblTitleInfo
            // 
            this.lblTitleInfo.AutoSize = true;
            this.lblTitleInfo.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTitleInfo.Location = new System.Drawing.Point(35, 77);
            this.lblTitleInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitleInfo.Name = "lblTitleInfo";
            this.lblTitleInfo.Size = new System.Drawing.Size(92, 21);
            this.lblTitleInfo.TabIndex = 66;
            this.lblTitleInfo.Text = "Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label1.Location = new System.Drawing.Point(37, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 23);
            this.label1.TabIndex = 90;
            this.label1.Text = "Employee Management";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblFname.Location = new System.Drawing.Point(13, 10);
            this.lblFname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(63, 16);
            this.lblFname.TabIndex = 63;
            this.lblFname.Text = "First Name";
            // 
            // tb_firstName
            // 
            this.tb_firstName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_firstName.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_firstName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_firstName.Location = new System.Drawing.Point(16, 27);
            this.tb_firstName.Name = "tb_firstName";
            this.tb_firstName.Size = new System.Drawing.Size(117, 20);
            this.tb_firstName.TabIndex = 64;
            this.tb_firstName.Tag = "tb";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblLname.Location = new System.Drawing.Point(150, 10);
            this.lblLname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(62, 16);
            this.lblLname.TabIndex = 65;
            this.lblLname.Text = "Last Name";
            // 
            // tb_lastName
            // 
            this.tb_lastName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_lastName.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_lastName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_lastName.Location = new System.Drawing.Point(153, 27);
            this.tb_lastName.Name = "tb_lastName";
            this.tb_lastName.Size = new System.Drawing.Size(117, 20);
            this.tb_lastName.TabIndex = 66;
            this.tb_lastName.Tag = "tb";
            // 
            // lblMname
            // 
            this.lblMname.AutoSize = true;
            this.lblMname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblMname.Location = new System.Drawing.Point(286, 10);
            this.lblMname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMname.Name = "lblMname";
            this.lblMname.Size = new System.Drawing.Size(76, 16);
            this.lblMname.TabIndex = 67;
            this.lblMname.Text = "Middle Name";
            // 
            // tb_middleName
            // 
            this.tb_middleName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_middleName.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_middleName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_middleName.Location = new System.Drawing.Point(289, 27);
            this.tb_middleName.Name = "tb_middleName";
            this.tb_middleName.Size = new System.Drawing.Size(117, 20);
            this.tb_middleName.TabIndex = 68;
            // 
            // cmb_sex
            // 
            this.cmb_sex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(248)))));
            this.cmb_sex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_sex.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_sex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.cmb_sex.FormattingEnabled = true;
            this.cmb_sex.Items.AddRange(new object[] {
            "M",
            "F"});
            this.cmb_sex.Location = new System.Drawing.Point(424, 25);
            this.cmb_sex.Name = "cmb_sex";
            this.cmb_sex.Size = new System.Drawing.Size(46, 24);
            this.cmb_sex.TabIndex = 69;
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblSex.Location = new System.Drawing.Point(421, 8);
            this.lblSex.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(26, 16);
            this.lblSex.TabIndex = 70;
            this.lblSex.Text = "Sex";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblAge.Location = new System.Drawing.Point(483, 10);
            this.lblAge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(28, 16);
            this.lblAge.TabIndex = 71;
            this.lblAge.Text = "Age";
            // 
            // tb_age
            // 
            this.tb_age.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_age.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_age.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_age.Location = new System.Drawing.Point(486, 27);
            this.tb_age.Name = "tb_age";
            this.tb_age.ReadOnly = true;
            this.tb_age.Size = new System.Drawing.Size(41, 20);
            this.tb_age.TabIndex = 72;
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblPhoneNum.Location = new System.Drawing.Point(540, 10);
            this.lblPhoneNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(85, 16);
            this.lblPhoneNum.TabIndex = 73;
            this.lblPhoneNum.Text = "Phone Number";
            // 
            // tb_phone
            // 
            this.tb_phone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_phone.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_phone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_phone.Location = new System.Drawing.Point(543, 27);
            this.tb_phone.MaxLength = 10;
            this.tb_phone.Name = "tb_phone";
            this.tb_phone.Size = new System.Drawing.Size(117, 20);
            this.tb_phone.TabIndex = 74;
            this.tb_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_phone_KeyPress);
            // 
            // dtp_bday
            // 
            this.dtp_bday.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.dtp_bday.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_bday.Location = new System.Drawing.Point(16, 73);
            this.dtp_bday.Name = "dtp_bday";
            this.dtp_bday.Size = new System.Drawing.Size(200, 20);
            this.dtp_bday.TabIndex = 75;
            this.dtp_bday.ValueChanged += new System.EventHandler(this.dtp_bday_ValueChanged);
            // 
            // lblBDate
            // 
            this.lblBDate.AutoSize = true;
            this.lblBDate.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblBDate.Location = new System.Drawing.Point(14, 57);
            this.lblBDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBDate.Name = "lblBDate";
            this.lblBDate.Size = new System.Drawing.Size(55, 16);
            this.lblBDate.TabIndex = 76;
            this.lblBDate.Text = "Birthdate";
            // 
            // cmb_status
            // 
            this.cmb_status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.cmb_status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_status.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_status.FormattingEnabled = true;
            this.cmb_status.Items.AddRange(new object[] {
            "ACTIVE",
            "INACTIVE"});
            this.cmb_status.Location = new System.Drawing.Point(244, 72);
            this.cmb_status.Name = "cmb_status";
            this.cmb_status.Size = new System.Drawing.Size(98, 24);
            this.cmb_status.TabIndex = 77;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblStatus.Location = new System.Drawing.Point(241, 54);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(41, 16);
            this.lblStatus.TabIndex = 78;
            this.lblStatus.Text = "Status";
            // 
            // cmb_role
            // 
            this.cmb_role.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.cmb_role.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_role.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_role.FormattingEnabled = true;
            this.cmb_role.Items.AddRange(new object[] {
            "ADMIN",
            "EMPLOYEE"});
            this.cmb_role.Location = new System.Drawing.Point(372, 72);
            this.cmb_role.Name = "cmb_role";
            this.cmb_role.Size = new System.Drawing.Size(98, 24);
            this.cmb_role.TabIndex = 79;
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRole.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblRole.Location = new System.Drawing.Point(369, 54);
            this.lblRole.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(30, 16);
            this.lblRole.TabIndex = 80;
            this.lblRole.Text = "Role";
            // 
            // lblPasswor
            // 
            this.lblPasswor.AutoSize = true;
            this.lblPasswor.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblPasswor.Location = new System.Drawing.Point(486, 56);
            this.lblPasswor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPasswor.Name = "lblPasswor";
            this.lblPasswor.Size = new System.Drawing.Size(59, 16);
            this.lblPasswor.TabIndex = 81;
            this.lblPasswor.Text = "Password";
            // 
            // tb_password
            // 
            this.tb_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.tb_password.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.tb_password.Location = new System.Drawing.Point(489, 73);
            this.tb_password.MaxLength = 10;
            this.tb_password.Name = "tb_password";
            this.tb_password.PasswordChar = '*';
            this.tb_password.Size = new System.Drawing.Size(117, 20);
            this.tb_password.TabIndex = 82;
            this.tb_password.Tag = "tb";
            // 
            // chk_show
            // 
            this.chk_show.AutoSize = true;
            this.chk_show.Font = new System.Drawing.Font("Inter", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_show.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.chk_show.Location = new System.Drawing.Point(612, 74);
            this.chk_show.Name = "chk_show";
            this.chk_show.Size = new System.Drawing.Size(55, 20);
            this.chk_show.TabIndex = 83;
            this.chk_show.Text = "show";
            this.chk_show.UseVisualStyleBackColor = true;
            this.chk_show.CheckedChanged += new System.EventHandler(this.chk_show_CheckedChanged);
            // 
            // pnlInformation
            // 
            this.pnlInformation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInformation.BackColor = System.Drawing.Color.White;
            this.pnlInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInformation.Controls.Add(this.chk_show);
            this.pnlInformation.Controls.Add(this.tb_password);
            this.pnlInformation.Controls.Add(this.lblPasswor);
            this.pnlInformation.Controls.Add(this.lblRole);
            this.pnlInformation.Controls.Add(this.cmb_role);
            this.pnlInformation.Controls.Add(this.lblStatus);
            this.pnlInformation.Controls.Add(this.cmb_status);
            this.pnlInformation.Controls.Add(this.lblBDate);
            this.pnlInformation.Controls.Add(this.dtp_bday);
            this.pnlInformation.Controls.Add(this.tb_phone);
            this.pnlInformation.Controls.Add(this.lblPhoneNum);
            this.pnlInformation.Controls.Add(this.tb_age);
            this.pnlInformation.Controls.Add(this.lblAge);
            this.pnlInformation.Controls.Add(this.lblSex);
            this.pnlInformation.Controls.Add(this.cmb_sex);
            this.pnlInformation.Controls.Add(this.tb_middleName);
            this.pnlInformation.Controls.Add(this.lblMname);
            this.pnlInformation.Controls.Add(this.tb_lastName);
            this.pnlInformation.Controls.Add(this.lblLname);
            this.pnlInformation.Controls.Add(this.tb_firstName);
            this.pnlInformation.Controls.Add(this.lblFname);
            this.pnlInformation.Location = new System.Drawing.Point(40, 105);
            this.pnlInformation.Margin = new System.Windows.Forms.Padding(2);
            this.pnlInformation.Name = "pnlInformation";
            this.pnlInformation.Size = new System.Drawing.Size(749, 105);
            this.pnlInformation.TabIndex = 84;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.button3.Image = global::POS_System.Properties.Resources.rotating_arrow_to_the_right_1__2_;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(652, 448);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(10, 0, 30, 0);
            this.button3.Size = new System.Drawing.Size(138, 35);
            this.button3.TabIndex = 50;
            this.button3.Text = "Update";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::POS_System.Properties.Resources.search__2_;
            this.button2.Location = new System.Drawing.Point(709, 4);
            this.button2.MaximumSize = new System.Drawing.Size(29, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(29, 30);
            this.button2.TabIndex = 60;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // EmployeeManagementScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.pnlBotoom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmployeeManagementScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeManagementScreen";
            this.pnlEmployee.ResumeLayout(false);
            this.pnlEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmp)).EndInit();
            this.pnlBotoom.ResumeLayout(false);
            this.pnlBotoom.PerformLayout();
            this.pnlInformation.ResumeLayout(false);
            this.pnlInformation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlEmployee;
        private System.Windows.Forms.Label lblTitleEmp;
        private System.Windows.Forms.Panel pnlBotoom;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dgvEmp;
        private System.Windows.Forms.Label lblTitleInfo;
        private System.Windows.Forms.Label lbl_employementID;
        private System.Windows.Forms.Label lblEmpIDDisplay;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.Panel panelChildform;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlInformation;
        private System.Windows.Forms.CheckBox chk_show;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Label lblPasswor;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.ComboBox cmb_role;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ComboBox cmb_status;
        private System.Windows.Forms.Label lblBDate;
        private System.Windows.Forms.DateTimePicker dtp_bday;
        private System.Windows.Forms.TextBox tb_phone;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.TextBox tb_age;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.ComboBox cmb_sex;
        private System.Windows.Forms.TextBox tb_middleName;
        private System.Windows.Forms.Label lblMname;
        private System.Windows.Forms.TextBox tb_lastName;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.TextBox tb_firstName;
        private System.Windows.Forms.Label lblFname;
    }
}