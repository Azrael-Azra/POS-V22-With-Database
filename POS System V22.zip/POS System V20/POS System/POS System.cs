﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace POS_System
{
    public partial class POS_System : Form
    {
        //Initialization and Variable Declaration
        databasePOS db;
        List<UserManager.MenuItem> menu = new List<UserManager.MenuItem>();
        //int id = 1;
        int currentIndex;
        public POS_System()
        {
            InitializeComponent();
            //Hides panel for receipt
            pnlReceipt.Hide();
        }

        //transfer storedProcedure to List
        private void getList()
        {
            //Instantiate database
            db = new databasePOS();

            //Adds database data to List
            menu.AddRange(from a in db.showPOSproducts()
                          select new UserManager.MenuItem
                          {
                              ID = a.Product_ID,
                              Name = a.Product_Name,
                              Price = (decimal)a.Price,
                              Image = a.Image.ToArray(),
                              Category = a.Category,
                              Stock = (int)a.Quantity
                          });

            getData("All");
        }

        //Shows the filtered item of the coresponding category
        private void getData(string cat)
        {
            //Instantiate database
            db = new databasePOS();

            //Clears controls on flowlayoutPanel
            flowpnlProducts.Controls.Clear();
            var product = menu.ToList();

            if (product != null)
            {
                if (cat != "All")
                {
                    product = product.Where(u => u.Category == cat).ToList();
                }

                foreach (var item in product)
                {
                    // Create a Panel to hold the design
                    Panel productPanel = new Panel
                    {
                        Size = new Size(140, 180),
                        BackColor = Color.White,
                        BorderStyle = BorderStyle.None,
                        Location = new Point(10, 10),
                        Margin = new Padding(5),
                        Tag = item
                    };

                    flowpnlProducts.Controls.Add(productPanel);

                    // PictureBox for the product image
                    PictureBox productImage = new PictureBox
                    {
                        Size = new Size(120, 80),
                        BackColor = Color.Gray,
                        Location = new Point(10, 25),
                        BorderStyle = BorderStyle.None,
                        SizeMode = PictureBoxSizeMode.StretchImage,
                    };
                    productPanel.Controls.Add(productImage);

                    if (item.Image != null)
                    {
                        using (MemoryStream ms = new MemoryStream(item.Image.ToArray()))
                        {
                            productImage.Image = Image.FromStream(ms);
                        }
                    }
                    else
                    {
                        productImage.Image = Properties.Resources.NA; // Default image
                    }

                    // Price Label
                    Label priceLabel = new Label
                    {
                        Text = $"P{item.Price:0.00}",
                        Font = new Font("Inter", 8, FontStyle.Regular),
                        ForeColor = Color.FromArgb(64, 64, 64),
                        TextAlign = ContentAlignment.MiddleRight,
                        Dock = DockStyle.Top,
                        Padding = new Padding(0, 3, 5, 0),
                        Height = 20
                    };
                    productPanel.Controls.Add(priceLabel);



                    // Product Name Label
                    Label productNameLabel = new Label
                    {
                        Text = item.Name,
                        Font = new Font("Inter", 9, FontStyle.Bold),
                        ForeColor = Color.FromArgb(34, 34, 34),
                        TextAlign = ContentAlignment.MiddleCenter,
                        Location = new Point(10, 110),
                        Size = new Size(110, 15)
                    };
                    productPanel.Controls.Add(productNameLabel);

                    // NumericUpDown for quantity input
                    NumericUpDown quantityInput = new NumericUpDown
                    {
                        Value = 0,
                        Location = new Point(10, 140),
                        Size = new Size(50, 20),
                    };
                    productPanel.Controls.Add(quantityInput);

                    // "Add Item" Button
                    Button addItemButton = new Button
                    {
                        Text = "Add",
                        BackColor = Color.FromArgb(21, 148, 14),
                        ForeColor = Color.WhiteSmoke,
                        Font = new Font("Inter", 8),
                        Location = new Point(70, 137),
                        Size = new Size(60, 25),
                        FlatStyle = FlatStyle.Flat,
                        FlatAppearance = { BorderSize = 0 },
                        Tag = item.Category
                    };
                    addItemButton.Click += addToOrder;
                    productPanel.Controls.Add(addItemButton);
                }
            }
        }

        //add order to datagridview
        private void addToOrder(object sender,EventArgs e)
        {

            Button clickedButton = (Button)sender;
            Panel productPanel = (Panel)clickedButton.Parent;

            UserManager.MenuItem selectedItem = (UserManager.MenuItem)productPanel.Tag;
            NumericUpDown quantityInput = productPanel.Controls.OfType<NumericUpDown>().FirstOrDefault();
            int quantity = (quantityInput != null) ? (int)quantityInput.Value : 0;
            double price = (double)selectedItem.Price;
            double subTotal = 0;

            if (quantity <= 0)
            {
                MessageBox.Show("Please select a quantity greater than 0.", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (quantity > selectedItem.Stock)
            {
                MessageBox.Show($"Cannot add {quantity} items. Only {selectedItem.Stock} items in stock", "Stock Limit Exceeded", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                quantityInput.Value = 0;
                return;
            }


            // Check for duplicates in the DataGridView
            foreach (DataGridViewRow row in dgvProducts.Rows)
            {
                // Skip empty or new rows (e.g., the placeholder row)
                if (row.IsNewRow) continue;

                // Ensure the cell is not null before comparing
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == selectedItem.Name)
                {
                    // Update the quantity
                    int existingQuantity = (int)row.Cells[2].Value; // Assuming column index 2 is quantity
                    if (existingQuantity + quantity > selectedItem.Stock)
                    {
                        MessageBox.Show($"Cannot add {quantity} items. Only {selectedItem.Stock} items in stock", "Stock Limit Exceeded", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    row.Cells[2].Value = existingQuantity + quantity;

                    //Update the subTotal
                    subTotal = (existingQuantity + quantity) * price;
                    row.Cells[5].Value = "P" + subTotal;
                    
                    // Reset the quantity input and exit
                    quantityInput.Value = 0;
                    return;
                }
            }

            subTotal = quantity * price;

            // If no duplicate found, add a new row
            dgvProducts.Rows.Add(selectedItem.ID, selectedItem.Name, quantity, selectedItem.Price, selectedItem.Category, "P" + subTotal);
            quantityInput.Value = 0;

            CalculateTotal();
        }

        //show meat items
        private void btnMeat_Click(object sender, EventArgs e)
        {
            getData("Meat");
        }

        //show food items
        private void btnFood_Click(object sender, EventArgs e)
        {
            getData("Food");
        }

        //show drinks items
        private void btnDrinks_Click(object sender, EventArgs e)
        {
            getData("Drinks");
        }

        //show addon items
        private void btnAddons_Click(object sender, EventArgs e)
        {

            getData("Snacks");
        }

        //Calculate the ordered Product
        private void btnSaveReceipt_Click(object sender, EventArgs e)
        {
            if (dgvProducts.Rows.Count > 1)
            {
                //dgvProducts.Rows.Clear();
                CalculateChange();
            }
            
        }

        //Method for calculating totals
        private void CalculateTotal()
        {
            int totalQuantity = 0; // To store the total quantity
            decimal totalPrice = 0m; // To store the total price

            // Iterate through all rows in the DataGridView
            foreach (DataGridViewRow row in dgvProducts.Rows)
            {
                // Skip the placeholder new row
                if (row.IsNewRow) continue;

                // Extract quantity and price values (ensure they are not null)
                int quantity = row.Cells[2].Value != null ? Convert.ToInt32(row.Cells[2].Value) : 0; // Assuming column index 2 is Quantity
                decimal price = row.Cells[3].Value != null ? Convert.ToDecimal(row.Cells[3].Value) : 0; // Assuming column index 3 is Price

                // Add to totals
                totalQuantity += quantity;
                totalPrice += quantity * price; // Multiply quantity by price for each row
            }

            // Display the results (e.g., in labels or message box)
            //lblTotalQuantity.Text = $"Total Quantity: {totalQuantity}";
          
            

            lbl_total.Text = $"P{totalPrice:0.00}";

            
        }


        //Method for Change Calculation
        private void CalculateChange() 
        {
            string error = String.Empty;
            if (!string.IsNullOrEmpty(txtPaidInCash.Text))
            {
                decimal amountTendered;
                if (decimal.TryParse(txtPaidInCash.Text, out amountTendered))
                {
                    decimal amountToPaid;

                    if (decimal.TryParse(lbl_total.Text.TrimStart('P'),out amountToPaid))
                    {

                    }

                    if (amountTendered < amountToPaid)
                    {
                        error += "Amount tender is less than the Amount to pay";
                        MessageBox.Show("Amount tender is less than the Amount to pay","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                    else
                    {
                        decimal totalChange = amountTendered - amountToPaid;
                        lblChangeAmt.Text = $"P{totalChange:0.00}";

                        //Add to sales report
                        //db.SalesReport(int.Parse(UserManager.id), DateTime.Now, amountToPaid, amountTendered, totalChange);
                        var transaction = db.SalesReport(int.Parse(UserManager.id), DateTime.Now, amountToPaid, amountTendered, totalChange).FirstOrDefault();
                        int TransactionID = Convert.ToInt32(transaction.CurrentIndex);

                        
                        
                        //Deduct the quantitys to the inventory
                        db = new databasePOS();
                        foreach (DataGridViewRow row in dgvProducts.Rows)
                        {
                            if (row.IsNewRow) continue;

                            int prodID = int.Parse(row.Cells[0].Value.ToString());
                            int quantity = int.Parse(row.Cells[2].Value.ToString());
                            string subTotal = row.Cells[5].Value.ToString();

                            if (decimal.TryParse(subTotal.TrimStart('P'),out decimal Sub))
                            {
                                
                            }
                            db.stockOutInventory(prodID, quantity);
                            db.InventoryReports(TransactionID.ToString(),prodID,int.Parse(UserManager.id),quantity,"Stock-Out",DateTime.Now);
                            db.salesReportDetails(TransactionID,prodID,quantity,Sub);
                        }
                       
                        MessageBox.Show("Success", "Success", MessageBoxButtons.OK,MessageBoxIcon.Information);
                        pnlReceipt.Show();

                        //Clears rows and columns
                        dgv_receipt.Rows.Clear();
                        dgv_receipt.Columns.Clear();

                        dgv_receipt.Columns.Add("Column 1", dgvProducts.Columns[1].HeaderText);
                        dgv_receipt.Columns.Add("Column 2", dgvProducts.Columns[2].HeaderText);
                        dgv_receipt.Columns.Add("Column 3", dgvProducts.Columns[3].HeaderText);
                        dgv_receipt.Columns.Add("Column 4", dgvProducts.Columns[5].HeaderText);
                        foreach (DataGridViewRow row in dgvProducts.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                int newRowIndex = dgv_receipt.Rows.Add();

                                dgv_receipt.Rows[newRowIndex].Cells[0].Value = row.Cells[1].Value;
                                dgv_receipt.Rows[newRowIndex].Cells[1].Value = row.Cells[2].Value;
                                dgv_receipt.Rows[newRowIndex].Cells[2].Value = row.Cells[3].Value;
                                dgv_receipt.Rows[newRowIndex].Cells[3].Value = row.Cells[5].Value;
                            }
                        }

                        getData("All");
                        

                        //Populate panel receipt information
                        lbl_transactionNumber.Text = TransactionID.ToString();
                        lbl_userID.Text = UserManager.id;
                        lbl_date.Text = DateTime.Now.ToString();
                        lbl_receiptTotal.Text = $"P{amountToPaid:0.00}";
                        lbl_receiptAmountTendered.Text = $"P{amountTendered:0.00}";
                        lbl_receiptChanged.Text = $"P{totalChange:0.00}";



                        //dgv_receipt.DataSource = null;
                        //// Assuming the first DataGridView is populated with a DataTable
                        //DataTable originalData = (DataTable)dgvProducts.DataSource;

                        //// Create a copy or filter data as needed
                        //DataTable copiedData = originalData.Copy(); // Copying the original table

                        //// Bind the copied data to the second DataGridView
                        //dgv_receipt.DataSource = copiedData;

                    }
                }
                else
                {
                    MessageBox.Show("Invalid Amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPaidInCash.Text = "";
                    txtPaidInCash.Focus();
                }
            }
            else
            {
                MessageBox.Show("Amount cannot be empty", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtPaidInCash.Text = "";
                txtPaidInCash.Focus();
            }

            error = String.Empty;
            
        }


        //Role Verification
        private bool AdminVerification() 
        {
            return UserManager.role == "ADMIN";
        }

        //Password Verification
        private bool PasswordVerification(string voidPassword) 
        {
            string adminPassword = "ADMIN1234";
            return voidPassword == adminPassword;
        }

        //New Form Creation For Admin Password
        private string AdminPasswordWindow() 
        {

            using (Form voidRemove = new Form() { Width = 250, Height = 200, BackColor = Color.White, FormBorderStyle = FormBorderStyle.FixedSingle})
            {
                Label lblHeader = new Label { Text = "VOID ACCESS", Left = 100, Top = 20, Font = new Font("Inter", 10, FontStyle.Bold), ForeColor = Color.FromArgb(34,34,34) };
                Label lblPassword = new Label { Text = "Enter Admin Password:", Left = 50, Top = 60, Font = new Font("Inter", 9) };
                TextBox tbPass = new TextBox { Left = 50, Top = 80, Width = 150, PasswordChar = '*', Font = new Font("Inter", 9)};
                Button btnSubmit = new Button { Text = "Submit", Left = 70, Top = 120 , Width = 100, Height = 30, BackColor = Color.FromArgb(1, 182, 102), FlatStyle = FlatStyle.Flat, FlatAppearance = { BorderSize = 0}, ForeColor = Color.White };

                btnSubmit.Click += (s, e) => { voidRemove.DialogResult = DialogResult.OK; voidRemove.Close(); };

                voidRemove.Controls.Add(lblHeader);
                voidRemove.Controls.Add(lblPassword);
                voidRemove.Controls.Add(tbPass);
                voidRemove.Controls.Add(btnSubmit);
                voidRemove.StartPosition = FormStartPosition.CenterScreen;
                voidRemove.ShowDialog();

                return tbPass.Text;
            }
        }

        //Update the total
        private void dgvProducts_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            CalculateTotal();
        }

        //Textbox restrictions for letters and double dot on Cash input
        private void txtPaidInCash_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            // Allow digits, one dot, and backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignore invalid characters
                return;
            }

            // Allow backspace to function
            if (e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false; // Do not block the backspace
                return;
            }

            // Check for one decimal point
            if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true; // Prevent multiple decimal points
                return;
            }

            // Split the current text into integer and decimal parts
            string[] parts = textBox.Text.Split('.');
            string integerPart = parts[0]; // The part before the decimal
            string decimalPart = parts.Length > 1 ? parts[1] : ""; // The part after the decimal

            // Check if integer part exceeds 7 digits
            if (integerPart.Length >= 10 && textBox.SelectionStart <= integerPart.Length && e.KeyChar != '.')
            {
                e.Handled = true; // Stop input if already 7 digits before the decimal
                return;
            }

            // Restrict decimal part to 2 digits
            if (textBox.Text.Contains(".") && decimalPart.Length >= 2 && textBox.SelectionStart > integerPart.Length)
            {
                e.Handled = true; // Stop input if 2 decimal places are reached
                return;
            }

            // Limit overall text length to 10 characters (7 digits + 1 dot + 2 decimal places)
            if (textBox.Text.Length >= 13 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Stop input if length exceeds 13
                return;
            }
        }

        private void txtEditQty_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                currentIndex = int.Parse(dgvProducts.Rows[e.RowIndex].Cells[2].Value.ToString());
                lblItemID_.Text = dgvProducts.Rows[e.RowIndex].Cells[0].Value.ToString();
                //numUpdown_qty.Value = currentIndex;
            }
        }

        //New Transaction
        private void btnNewTransc_Click(object sender, EventArgs e)
        {
            dgvProducts.Rows.Clear();
            lbl_total.Text = "--";
            txtPaidInCash.Text = "";
            lblChangeAmt.Text = "";
            btnSaveReceipt.Enabled = true;
            txtPaidInCash.ReadOnly = false;
            pnlReceipt.Hide();
            menu.Clear();
            getList();
            //pnlBg.Hide();
        }

        //Show all products
        private void btn_All_Click(object sender, EventArgs e)
        {
            getData("All");
        }

        //Removing item from datagridview
        private void btn_void_Click(object sender, EventArgs e)
        {
            if (dgvProducts.Rows.Count > 1)
            {
                //Check if there's a selected row
                if (dgvProducts.SelectedCells.Count > 0)
                {
                    //Get the selected row
                    int selectedProd = dgvProducts.SelectedCells[0].RowIndex;

                    //User Role Verification
                    if (AdminVerification())
                    {
                        dgvProducts.Rows.RemoveAt(selectedProd);
                        MessageBox.Show("Item Removed Succesfully!.", "Access Granted!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CalculateTotal();
                    }
                    else
                    {
                        //If user role is Employee, ask for a Admin password
                        string adminPass = AdminPasswordWindow();
                        if (PasswordVerification(adminPass)) //Password Checker
                        {
                            dgvProducts.Rows.RemoveAt(selectedProd);
                            MessageBox.Show("Item Removed Succesfully!.", "Access Granted!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CalculateTotal();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect Admin password. You are not authorized to remove this item.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select an item to remove.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            
        }

        private void txtPaidInCash_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dgvProducts.Rows.Count > 1)
                {
                    //dgvProducts.Rows.Clear();
                    CalculateChange();
                }
            }
        }

        //Load Product List
        private void POS_System_Load(object sender, EventArgs e)
        {
            getList();
        }

    }
}
