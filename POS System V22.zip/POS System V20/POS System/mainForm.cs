﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class mainForm : Form
    {
        Login login;
        public mainForm(Login _login)
        {
            InitializeComponent();
            panelChildform.Visible = true;
            OpenChildform(new welcomeScreen());
            tmrAnimation.Start();
            pnlLevels.Width = 0;
            setRole();
            login = _login;

        }

        //configure role upon login
        private void setRole()
        {
            if (UserManager.role == "EMPLOYEE")
            {
                
                btnProductsManagement.Hide();
                btnInventoryManagement.Hide();
                btnTransactionsReport.Hide();
            }
            else
            {
                btnSalesReport.Show();
                btnProductsManagement.Show();
                btnInventoryManagement.Show();
                btnTransactionsReport.Show();
                btnSalesReport.Show();
            }
        }

        //create child and parent form
        private Form activeForm = null;
        private void OpenChildform(Form childform)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelChildform.Controls.Add(childform);
            panelChildform.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        //trigger register button
        private void btnRegistration_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new RegistrationScreen());
        }

        //open employeeemnagement
        private void btnEmployeeManagement_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            if (UserManager.role == "EMPLOYEE")
            {
                OpenChildform(new EditEmployeeDetails());
            }
            else
            {
                OpenChildform(new EmployeeManagementScreen());
            }
            
        }

        //animation
        private void timer1_Tick(object sender, EventArgs e)
        {
            pnlLevels.Width += 12;
            if (pnlLevels.Width == pnlLevels.MaximumSize.Width)
            {
                tmrAnimation.Dispose();
            }
        }

        //oepn Products Management
        private void btnProductsManagement_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new ProductManagement());
        }

        private void btnInventoryManagement_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new InventoryManagement());
        }

        private void btnEmployeeManagement_Click_1(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            if (UserManager.role == "EMPLOYEE")
            {
                OpenChildform(new EditEmployeeDetails());
            }
            else
            {
                OpenChildform(new EmployeeManagementScreen());
            }
        }

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new SalesReport());
        }

        private void btnTransactionsReport_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new InventoryReport());
        }

        private void btnPOS_Click(object sender, EventArgs e)
        {
            panelChildform.Visible = true;
            OpenChildform(new POS_System());
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            login.showForm(); 
            this.Dispose();
        }

        //Exits the application
        private void mainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
