﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Management.Instrumentation;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class InventoryManagement : Form
    {
        //Instantiation and variable declaration
        databasePOS db;
        int currentIndex;
        int addQuantity;
        string category = "All";
        public InventoryManagement()
        {
            InitializeComponent();
            cmbSelection.SelectedIndex = 0;
            LoadItems("All");
        }

        //Populate DatagridView Method
        private void LoadItems(string cat)
        {
            db = new databasePOS();

            //clears the current data of the datagrid view
            dgv_showData.DataSource = null;

            //Makes the table queryiable
            var products = db.showfilteredInventory().ToList();
            if(products != null)
            {
                //shows all categories
                if (cat != "All")
                {
                    products = products.Where(u => u.Category == cat).ToList();
                }

                //populate datagrid
                dgv_showData.DataSource = products;

                dgv_showData.Columns[0].HeaderText = "Product ID";
                dgv_showData.Columns[1].HeaderText = "Product Name";
                dgv_showData.Columns[2].HeaderText = "Category";
                dgv_showData.Columns[3].HeaderText = "Quantity";
            }
        }

        //Load Items in categories
        private void cmbSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            category = cmbSelection.SelectedItem.ToString();
            LoadItems(category);
            currentIndex = 0;
            lbl_productID.Text = "--";
            lbl_productName.Text = "--";
            lbl_quantity.Text = "--";
        }

        //Gets the quantity of the selected cell
        private void dgv_showData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                currentIndex = int.Parse(dgv_showData.Rows[e.RowIndex].Cells[0].Value.ToString());

                var product = db.showfilteredInventory().FirstOrDefault(u => u.Product_Id == currentIndex);

                if (product != null)
                {
                    lbl_productID.Text = product.Product_Id.ToString();
                    lbl_productName.Text = product.Product_Name;
                    lbl_quantity.Text = product.Quantity.ToString();
                }
            }
        }

        //Add quantity
        private void btnSave_Click(object sender, EventArgs e)
        {
            addStock();
        }

        //Method in adding quantity
        private void addStock()
        {
            //Instantiate the database
            db = new databasePOS();

            //Gets the product by the product ID
            var productList = db.showfilteredInventory().ToList();
            var product = productList.Any(u => u.Product_Id == currentIndex);

            if (product)
            {
                string error = String.Empty;

                //Adds error
                if (numPad_quantity.Value == 0)
                {
                    error += "*Enter valid quantity\n";
                }

                //Adds error
                if (string.IsNullOrWhiteSpace(cmb_stockNumber.Text))
                {
                    error += "Select Stock Number";
                }

                if (error == String.Empty)
                {
                    //Prompt to proceed
                    DialogResult result = MessageBox.Show("Commit changes?","Warning!",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning);

                    if (result == DialogResult.OK)
                    {
                        //proceed to adding
                        db.addQuantity(currentIndex, (int)numPad_quantity.Value);

                        //DateTime dateNow = DateTime.Now;
                        //string formattedDate = dateNow.ToString("dd-MMM-yyyy",CultureInfo.InvariantCulture).ToUpper();
                        db.InventoryReports(cmb_stockNumber.Text, currentIndex,int.Parse(UserManager.id),(int)numPad_quantity.Value,"Stock-In",DateTime.Now);
                        MessageBox.Show($"Successfuly Added to the Product ID: {currentIndex}", "Success", MessageBoxButtons.OK,MessageBoxIcon.Information);
                        LoadItems(category);
                    }
                    
                }
                else
                {
                    MessageBox.Show(error,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        //quantity restriction
        private void numPadStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        //accepts digits only
        private void tb_stockNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled= true;
            }
        }

        //Search Product ID
        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            //Instantiate database
            db = new databasePOS();

            if (string.IsNullOrWhiteSpace(tb_search.Text.Trim()))
            {
                LoadItems("All");
            }
            else
            {
                //Filter search item
                var product = db.showfilteredInventory().FirstOrDefault(u => u.Product_Id == int.Parse(tb_search.Text.Trim()));

                if (product != null)
                {
                    dgv_showData.DataSource = null;
                    dgv_showData.DataSource = db.searchProductInventory(product.Product_Id);
                }
                else
                {
                    dgv_showData.DataSource = null;
                }
            }

            
            
        }

        //Accepts digit only
        private void tb_search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        
    }
}
