﻿namespace POS_System
{
    partial class InventoryManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgv_showData = new System.Windows.Forms.DataGridView();
            this.lbl_productName = new System.Windows.Forms.Label();
            this.lbl_productID = new System.Windows.Forms.Label();
            this.numPad_quantity = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlBg = new System.Windows.Forms.Panel();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.cmbSelection = new System.Windows.Forms.ComboBox();
            this.lblProducts = new System.Windows.Forms.Label();
            this.pnlInformation = new System.Windows.Forms.Panel();
            this.cmb_stockNumber = new System.Windows.Forms.ComboBox();
            this.lbl_max = new System.Windows.Forms.Label();
            this.lbl_quantity = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblStockNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitleInfo = new System.Windows.Forms.Label();
            this.lblMname = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPad_quantity)).BeginInit();
            this.pnlBg.SuspendLayout();
            this.pnlInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.lblTitle.Location = new System.Drawing.Point(37, 39);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(195, 23);
            this.lblTitle.TabIndex = 43;
            this.lblTitle.Text = "Inventory Management";
            // 
            // dgv_showData
            // 
            this.dgv_showData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_showData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_showData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.dgv_showData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_showData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_showData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_showData.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_showData.Location = new System.Drawing.Point(12, 40);
            this.dgv_showData.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_showData.Name = "dgv_showData";
            this.dgv_showData.ReadOnly = true;
            this.dgv_showData.RowHeadersWidth = 51;
            this.dgv_showData.RowTemplate.Height = 24;
            this.dgv_showData.Size = new System.Drawing.Size(723, 252);
            this.dgv_showData.TabIndex = 44;
            this.dgv_showData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_showData_CellClick);
            // 
            // lbl_productName
            // 
            this.lbl_productName.AutoSize = true;
            this.lbl_productName.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_productName.Location = new System.Drawing.Point(90, 57);
            this.lbl_productName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_productName.Name = "lbl_productName";
            this.lbl_productName.Size = new System.Drawing.Size(20, 17);
            this.lbl_productName.TabIndex = 83;
            this.lbl_productName.Text = "--";
            // 
            // lbl_productID
            // 
            this.lbl_productID.AutoSize = true;
            this.lbl_productID.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_productID.Location = new System.Drawing.Point(13, 57);
            this.lbl_productID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_productID.Name = "lbl_productID";
            this.lbl_productID.Size = new System.Drawing.Size(20, 17);
            this.lbl_productID.TabIndex = 81;
            this.lbl_productID.Text = "--";
            // 
            // numPad_quantity
            // 
            this.numPad_quantity.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPad_quantity.Location = new System.Drawing.Point(427, 54);
            this.numPad_quantity.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numPad_quantity.Name = "numPad_quantity";
            this.numPad_quantity.Size = new System.Drawing.Size(116, 20);
            this.numPad_quantity.TabIndex = 80;
            this.numPad_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numPadStock_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(182)))), ((int)(((byte)(102)))));
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSave.Location = new System.Drawing.Point(620, 48);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(114, 26);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Add to Inventory";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pnlBg
            // 
            this.pnlBg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBg.BackColor = System.Drawing.Color.White;
            this.pnlBg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBg.Controls.Add(this.label2);
            this.pnlBg.Controls.Add(this.tb_search);
            this.pnlBg.Controls.Add(this.cmbSelection);
            this.pnlBg.Controls.Add(this.dgv_showData);
            this.pnlBg.Controls.Add(this.lblProducts);
            this.pnlBg.Location = new System.Drawing.Point(40, 176);
            this.pnlBg.Name = "pnlBg";
            this.pnlBg.Size = new System.Drawing.Size(750, 306);
            this.pnlBg.TabIndex = 83;
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Location = new System.Drawing.Point(561, 14);
            this.tb_search.Margin = new System.Windows.Forms.Padding(2);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(174, 20);
            this.tb_search.TabIndex = 67;
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            this.tb_search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_search_KeyPress);
            // 
            // cmbSelection
            // 
            this.cmbSelection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.cmbSelection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelection.Font = new System.Drawing.Font("Inter", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelection.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.cmbSelection.FormattingEnabled = true;
            this.cmbSelection.Items.AddRange(new object[] {
            "All",
            "Drinks",
            "Food",
            "Meat",
            "Snacks"});
            this.cmbSelection.Location = new System.Drawing.Point(93, 10);
            this.cmbSelection.Name = "cmbSelection";
            this.cmbSelection.Size = new System.Drawing.Size(130, 24);
            this.cmbSelection.Sorted = true;
            this.cmbSelection.TabIndex = 66;
            this.cmbSelection.SelectedIndexChanged += new System.EventHandler(this.cmbSelection_SelectedIndexChanged);
            // 
            // lblProducts
            // 
            this.lblProducts.AutoSize = true;
            this.lblProducts.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProducts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblProducts.Location = new System.Drawing.Point(13, 13);
            this.lblProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(73, 21);
            this.lblProducts.TabIndex = 42;
            this.lblProducts.Text = "Category";
            // 
            // pnlInformation
            // 
            this.pnlInformation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInformation.BackColor = System.Drawing.Color.White;
            this.pnlInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInformation.Controls.Add(this.cmb_stockNumber);
            this.pnlInformation.Controls.Add(this.lbl_max);
            this.pnlInformation.Controls.Add(this.lbl_quantity);
            this.pnlInformation.Controls.Add(this.lblQuantity);
            this.pnlInformation.Controls.Add(this.lblStockNumber);
            this.pnlInformation.Controls.Add(this.label1);
            this.pnlInformation.Controls.Add(this.lblTitleInfo);
            this.pnlInformation.Controls.Add(this.lblMname);
            this.pnlInformation.Controls.Add(this.lbl_productName);
            this.pnlInformation.Controls.Add(this.lblLname);
            this.pnlInformation.Controls.Add(this.numPad_quantity);
            this.pnlInformation.Controls.Add(this.lbl_productID);
            this.pnlInformation.Controls.Add(this.btnSave);
            this.pnlInformation.Controls.Add(this.lblFname);
            this.pnlInformation.Location = new System.Drawing.Point(40, 75);
            this.pnlInformation.Margin = new System.Windows.Forms.Padding(2);
            this.pnlInformation.Name = "pnlInformation";
            this.pnlInformation.Size = new System.Drawing.Size(750, 86);
            this.pnlInformation.TabIndex = 85;
            // 
            // cmb_stockNumber
            // 
            this.cmb_stockNumber.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cmb_stockNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_stockNumber.FormattingEnabled = true;
            this.cmb_stockNumber.Items.AddRange(new object[] {
            "0001",
            "0002",
            "0003",
            "0004",
            "0005",
            "0006",
            "0007",
            "0008",
            "0009",
            "0010"});
            this.cmb_stockNumber.Location = new System.Drawing.Point(281, 51);
            this.cmb_stockNumber.Name = "cmb_stockNumber";
            this.cmb_stockNumber.Size = new System.Drawing.Size(121, 21);
            this.cmb_stockNumber.TabIndex = 68;
            // 
            // lbl_max
            // 
            this.lbl_max.AutoSize = true;
            this.lbl_max.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_max.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lbl_max.Location = new System.Drawing.Point(545, 56);
            this.lbl_max.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_max.Name = "lbl_max";
            this.lbl_max.Size = new System.Drawing.Size(64, 16);
            this.lbl_max.TabIndex = 91;
            this.lbl_max.Text = "(Max: 500)";
            // 
            // lbl_quantity
            // 
            this.lbl_quantity.AutoSize = true;
            this.lbl_quantity.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_quantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_quantity.Location = new System.Drawing.Point(212, 57);
            this.lbl_quantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_quantity.Name = "lbl_quantity";
            this.lbl_quantity.Size = new System.Drawing.Size(20, 17);
            this.lbl_quantity.TabIndex = 88;
            this.lbl_quantity.Text = "--";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblQuantity.Location = new System.Drawing.Point(212, 35);
            this.lblQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(51, 16);
            this.lblQuantity.TabIndex = 87;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblStockNumber
            // 
            this.lblStockNumber.AutoSize = true;
            this.lblStockNumber.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblStockNumber.Location = new System.Drawing.Point(293, 35);
            this.lblStockNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStockNumber.Name = "lblStockNumber";
            this.lblStockNumber.Size = new System.Drawing.Size(82, 16);
            this.lblStockNumber.TabIndex = 85;
            this.lblStockNumber.Text = "Stock Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(616, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 21);
            this.label1.TabIndex = 84;
            this.label1.Text = "Actions";
            // 
            // lblTitleInfo
            // 
            this.lblTitleInfo.AutoSize = true;
            this.lblTitleInfo.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTitleInfo.Location = new System.Drawing.Point(12, 10);
            this.lblTitleInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitleInfo.Name = "lblTitleInfo";
            this.lblTitleInfo.Size = new System.Drawing.Size(90, 21);
            this.lblTitleInfo.TabIndex = 69;
            this.lblTitleInfo.Text = "Item Details";
            // 
            // lblMname
            // 
            this.lblMname.AutoSize = true;
            this.lblMname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblMname.Location = new System.Drawing.Point(424, 35);
            this.lblMname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMname.Name = "lblMname";
            this.lblMname.Size = new System.Drawing.Size(117, 16);
            this.lblMname.TabIndex = 67;
            this.lblMname.Text = "Quantity to be added";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblLname.Location = new System.Drawing.Point(90, 35);
            this.lblLname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(63, 16);
            this.lblLname.TabIndex = 65;
            this.lblLname.Text = "Item Name";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblFname.Location = new System.Drawing.Point(13, 35);
            this.lblFname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(44, 16);
            this.lblFname.TabIndex = 63;
            this.lblFname.Text = "Item ID";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(498, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 92;
            this.label2.Text = "ID Search";
            // 
            // InventoryManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.pnlInformation);
            this.Controls.Add(this.pnlBg);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InventoryManagement";
            this.Text = "InventoryManagementTrue";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPad_quantity)).EndInit();
            this.pnlBg.ResumeLayout(false);
            this.pnlBg.PerformLayout();
            this.pnlInformation.ResumeLayout(false);
            this.pnlInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgv_showData;
        private System.Windows.Forms.Label lbl_productID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Panel pnlBg;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Label lbl_productName;
        private System.Windows.Forms.NumericUpDown numPad_quantity;
        private System.Windows.Forms.Panel pnlInformation;
        private System.Windows.Forms.Label lblMname;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.Label lblTitleInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStockNumber;
        private System.Windows.Forms.Label lbl_quantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lbl_max;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.ComboBox cmbSelection;
        private System.Windows.Forms.ComboBox cmb_stockNumber;
        private System.Windows.Forms.Label label2;
    }
}