﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public static class Products
    {
        //instantiate static database
        public static databasePOS db;

        //filter products by categories
        public static void filterCategory(string category)
        {
            db = new databasePOS();
            var product = db.tblProducts.Where(p => p.Category == category).ToList();
        }
    }
}
